Frontend-nanodegree-arcade-game
===============================
Purpose: 
-------
This game is used to practice <br/>
1: Object-Oriented JavaScript <br/>
2: HTML5 Canvas <br/>
How to Play:
-----------

1: Use "up", "down", "left", "right" keys to control characters movement.
<p align="center">
  <img src="https://github.com/hermanwu/frontend-nanodegree-arcade-game/blob/master/readme_images/move.PNG?raw=true"/>
</p>
2: Avoid the moving bugs. If bugs touch the character, you will lose the game.
<p align="center">
  <img src="https://github.com/hermanwu/frontend-nanodegree-arcade-game/blob/master/readme_images/lost.PNG?raw=true"/>
</p>
3: In order to win the game, the character needs to collect all gems.
<p align="center">
  <img src="https://github.com/hermanwu/frontend-nanodegree-arcade-game/blob/master/readme_images/won.PNG?raw=true"/>
</p>
4: No matter you win or lose the game, you can always press the "Restart" button to reset the game. 




